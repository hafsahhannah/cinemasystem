<html>
<title>Cine-art | Loading</title>
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Bellota:wght@700&family=DM+Sans:wght@400;500&display=swap');    </style>
    <link rel="stylesheet" href="1.css" />
</head>

<?php
header("Refresh:2; URL=login.php");
?>
<body align="center" style="background: black;">
<div class="centered">
    <legend style="font-size: 4vmax;">LOADING</legend>
    <div class="centered"">
<!--    <fieldset><label id="passprob">Redirecting you in a few seconds<label></fieldset>-->
</div>
</div>
</body>

</html>

